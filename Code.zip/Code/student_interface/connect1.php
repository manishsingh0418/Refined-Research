<?php
mysqli_connect('localhost:3306','root','');
mysqli_select_db('faculty1');

?>
